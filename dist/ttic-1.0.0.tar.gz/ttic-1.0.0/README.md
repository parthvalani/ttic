## Con2img
It takes tabular data and convert it to the RGB images.

## Installation
```pip install con2img```

## How to use it?

Import the package
Then,
```x_train, x_test = con2img(train_x,,train_y,test_y)```
where train_x = training inputs,
      test_x = testing inputs,
      train_y = one-hot encoding form of training labels.

## License

© 2021 Parth Valani

This repository is licensed under the MIT license. See LICENSE for details.