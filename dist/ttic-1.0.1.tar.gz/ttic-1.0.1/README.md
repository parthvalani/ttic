## ttic
It takes tabular data and convert it to the RGB images.

## Installation
```pip install ttic```

## How to use it?

```x_train, x_test = ttic(train_x,,train_y,test_y)```

## License

© 2021 Parth Valani

This repository is licensed under the MIT license. See LICENSE for details."# ttic" 
